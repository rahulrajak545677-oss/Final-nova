// Creates your permanent app signing key. Run ONCE:  npm run keystore
// Needs Java's keytool (included with Android Studio / any JDK).
const { spawnSync } = require('child_process');
const fs = require('fs');
const out = 'nova-release.keystore';
if (fs.existsSync(out)) { console.log(out + ' already exists. Not overwriting it.'); process.exit(1); }
console.log('Creating the NOVA signing key.\n' +
  '- Use the SAME strong password for the keystore and the key (just press Enter at the key password question).\n' +
  '- Alias is "nova". Write the password down somewhere safe.\n');
const r = spawnSync('keytool', ['-genkeypair', '-v', '-keystore', out, '-alias', 'nova',
  '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000'], { stdio: 'inherit' });
if (r.error || r.status !== 0) { console.error('keytool failed. Install a JDK (Android Studio includes one) and try again.'); process.exit(1); }
fs.writeFileSync(out + '.b64.txt', fs.readFileSync(out).toString('base64'));
console.log('\nDone. Files created in this folder:\n' +
  '  ' + out + '            <- your signing key. BACK IT UP. Never upload it to GitHub.\n' +
  '  ' + out + '.b64.txt    <- same key as text, to paste into the GitHub secret NOVA_KEYSTORE_B64.\n' +
  'Next: follow RELEASE.md, step 2.');
