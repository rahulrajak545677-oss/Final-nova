// Adds release signing + versioning to android/app/build.gradle (safe to run twice).
// Signing info comes from environment variables (CI) or android/keystore.properties (your computer).
module.exports = function patchGradle(g, version) {
  if (g.includes('NOVA release signing')) return { text: g, changed: false, ok: true };
  let t = g;
  // 1) the release build type signs with the release key
  t = t.replace(/(buildTypes\s*\{[\s\S]*?release\s*\{\n)/, (m) => m + '            signingConfig signingConfigs.release\n');
  // 2) version: code from CI run number, name from package.json
  t = t.replace(/versionCode\s+\d+/, "versionCode Integer.parseInt(System.getenv('NOVA_VERSION_CODE') ?: '1')");
  t = t.replace(/versionName\s+"[^"]*"/, 'versionName "' + version + '"');
  // 3) key loader + signingConfigs block
  const top = [
    '// NOVA release signing',
    'def novaProps = new Properties()',
    "def novaPropsFile = rootProject.file('keystore.properties')",
    'if (novaPropsFile.exists()) { novaPropsFile.withInputStream { novaProps.load(it) } }',
    'def novaProp = { String envName, String key -> System.getenv(envName) ?: novaProps.getProperty(key) }',
    '',
  ].join('\n');
  const sc = [
    '    signingConfigs {',
    '        release {',
    "            def ks = novaProp('NOVA_KEYSTORE_PATH', 'storeFile')",
    '            if (ks) {',
    '                storeFile file(ks)',
    "                storePassword novaProp('NOVA_KEYSTORE_PASSWORD', 'storePassword')",
    "                keyAlias novaProp('NOVA_KEY_ALIAS', 'keyAlias')",
    "                keyPassword novaProp('NOVA_KEY_PASSWORD', 'keyPassword')",
    '            } else {',
    "                logger.warn('NOVA: no signing key configured. Release builds will fail until you add one (see RELEASE.md).')",
    '            }',
    '        }',
    '    }',
    '',
  ].join('\n');
  t = t.replace(/\nandroid\s*\{\n/, () => '\n' + top + '\nandroid {\n' + sc);
  const ok = t.includes('signingConfig signingConfigs.release') && t.includes('signingConfigs {') &&
    t.includes('NOVA_VERSION_CODE') && t.includes('versionName "' + version + '"');
  return { text: t, changed: true, ok };
};
