# NOVA AI Privacy Policy (template: edit, then publish on a web page)

Last updated: YYYY-MM-DD. Contact: YOUR_EMAIL

**Accounts are optional.** You can use NOVA without signing in. If you create an account, we store your email, a salted hash of your password (never the password), and a copy of your synced chats, projects, memory and settings on our server (Cloudflare) so they appear on your other devices. That data is not end-to-end encrypted. API keys, photos and generated images are not uploaded. You can delete your account and synced data in the app (Settings > Account > Delete account) or at YOUR_BACKEND_URL/account-deletion. Without an account, nothing is stored on any NOVA server.

**What stays on your phone (always):** your chats, saved projects, generated images (last 12), settings, memory notes and the API keys you enter. You can delete chats and data in the app, or by uninstalling it. Android cloud backup is turned off for the app.

**What is sent, only when you use a feature:**
- Your messages, attached photos or screenshots, and custom instructions go to **Google Gemini** (using your own key) to produce replies and images. Google's terms apply: https://policies.google.com/privacy
- If web search or link reading is on and the message needs it, the search text or pasted links go to **TinyFish**: https://www.tinyfish.ai
- If Gemini image generation is unavailable, the image prompt goes to **Pollinations** (image.pollinations.ai).
- If you set your own server in Settings > Advanced, messages go to that server instead.

**Permissions:** microphone (dictation and voice chat), camera (photos), notifications and "display over other apps" (the optional floating bubble, off by default). They are used only for those features.

**Not collected:** no ads, no analytics, no tracking, no sale of data.

**Children:** not directed at children under 13.

**Your keys:** keep them private. You can revoke them anytime in Google AI Studio or the TinyFish dashboard.

Changes to this policy will be posted here with a new date.
