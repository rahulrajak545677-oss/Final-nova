# NOVA AI: complete Android project

**Official release (signed app, Google Play ready): read `RELEASE.md`. Optional accounts and cloud sync: read `ACCOUNTS.md`.** The routes below make debug builds for testing only. Privacy policy template: `PRIVACY.md`.

NOVA AI as a real Android app (Capacitor). The app itself is `www/index.html`.
I could not build the APK for you (no Android SDK where I work), so use one of the two routes below.
Versions and the cloud build were written from documentation and are untested.

## Route A: build in the cloud from your phone or PC (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload everything from this folder (keep the `.github` folder).
3. Open the repo > **Actions** > **Build NOVA debug APK (testing only)** > **Run workflow**.
4. When it finishes, open the run and download **nova-ai-debug-apk** (a zip containing `app-debug.apk`).
5. Install `app-debug.apk` on your phone (allow "install unknown apps").

## Route B: build on your computer
Needs Node.js (LTS) and Android Studio.
1. `npm install`
2. `node setup.js`  (adds Android, microphone/camera permissions, icon, syncs)
3. `npm run open`   (opens Android Studio) > Build > Build APK(s)
   or `npm run apk` > `android/app/build/outputs/apk/debug/app-debug.apk`
Run `npx cap doctor` if versions complain.

## Connect the AI (keys inside the app)
Open the app > Settings > AI provider.
- Gemini key (free): https://aistudio.google.com/apikey, plus a model name. Tap **Test**.
- TinyFish key (optional): https://agent.tinyfish.ai/api-keys, for web search and link reading.
Keys stay on your phone and are sent only to Google and TinyFish. Never write your keys into the code
or share an APK that contains them. You can restrict or delete a key in Google AI Studio.

## Languages
Settings > App language: English, Hindi, Spanish, French, Arabic (right-to-left), Portuguese.
This changes menus and buttons. Replies already follow the language you write in.
"Translate screen to" sets the language used when translating screenshots.

## Bubble over other apps (Android app only, OFF by default)
1. Open the app > Settings > turn on **Bubble over other apps**.
2. Android opens "Display over other apps". Allow NOVA and come back: the bubble turns on by itself.
3. The bubble now floats over your apps. Drag it to a side; it fades and tucks into the edge when idle.
4. Tap it for a small quick-chat panel (refresh button = new quick chat, expand button = open the full app).
5. Turn the same switch off to remove it, or use the Stop button in its notification.

If the bubble disappears after a while: Settings > **Keep the bubble alive** > set NOVA to "Unrestricted" / "Don't optimize".
On Xiaomi, Oppo, Vivo, Realme and Samsung phones also allow "Autostart" and "Display pop-up windows" for NOVA.
If "Display over other apps" is greyed out for a sideloaded app, open App info > menu (three dots) > "Allow restricted settings".
Android never lets any overlay appear on the lock screen, on some system screens, or over apps that block overlays for security (many banking apps).
On Android 13+ allow notifications for NOVA so you can see the Stop button.

## Image generation
- Say "draw a cat", "generate a logo...", or use + > Generate image.
- NOVA tries your Gemini image model first (Settings > Gemini > image model, default gemini-2.5-flash-image).
  Google may not give free-tier quota for image models on every account.
- If that fails, it falls back to the free Pollinations generator (no key; anonymous use is rate-limited and can be down).
- Attach a photo and ask for an edit to use Gemini image editing (needs your Gemini key and image model access).
- Generated images are saved on the phone (the last 12) and can be downloaded or shared.

## Features (NOVA AI 2.0)
- Liquid-glass interface: frosted, translucent panels over a slowly moving colour backdrop, glass tab bar, glass input, glass bubble.
- ChatGPT-style chat: streaming replies, markdown and code blocks with copy, stop, regenerate, copy, read aloud, thumbs up/down,
  follow-up chips (simpler / example / shorter / continue), edit and resend your own message, rename / share / delete a chat
  (tap the chat title), pin and search chats, temporary chat (not saved), text size.
- Create: apps and websites with live preview, code, documents, ideas; image generation and photo editing.
- Understands images and screenshots, camera, files, link reading and web search (TinyFish).
- Voice: dictation, hands-free voice chat, read replies aloud. Memory across chats and custom instructions.
- Floating bubble: in the app, and over other apps in the Android build. The quick-chat panel has a refresh button
  that starts a fresh quick chat, and an expand button that opens the full app.
- Six app languages (Hindi, Spanish, French, Arabic RTL, Portuguese, English), reply length, creativity, Gemini and TinyFish keys on your phone.

## After editing www/index.html
Run `npm run sync`, then build again (Route A: just upload the changed file).

## Limits
- It cannot read other apps' screens. Attach a screenshot with + > Photo or screenshot.
- The floating bubble works inside the app, not over other apps (that needs a native overlay service).
- Optional: `worker/worker.js` is a server you can host yourself (Settings > Advanced). Set its
  `ALLOWED_ORIGIN` to `https://localhost`.
