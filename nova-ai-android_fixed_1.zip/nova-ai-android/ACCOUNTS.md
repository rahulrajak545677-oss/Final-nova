# Accounts and cloud sync (optional)

Without a backend the app works as before: no sign-in, everything stays on the phone.
With the NOVA backend, people can create an account (email + password) and sync chats, projects, memory and settings
across devices. **API keys are never synced.** Everything runs on Cloudflare's free plan.

## Set up the backend (about 10 minutes, no coding)
1. Create a free Cloudflare account. Go to **Workers & Pages > D1 > Create database**, name it `nova`.
2. Open the database > **Console**, paste everything from `worker/schema.sql`, and run it.
3. **Workers & Pages > Create > Worker**, name it `nova-backend`, deploy, then **Edit code**, replace everything with `worker/worker.js`, and deploy.
4. Worker > **Settings > Bindings > Add > D1 database**. Variable name must be exactly `DB`, database `nova`.
5. Worker > **Settings > Variables and secrets**:
   | Name | Value |
   |---|---|
   | `ALLOWED_ORIGIN` | `https://localhost` (the Android app) |
   | `GEMINI_API_KEY` (secret) and `GEMINI_MODEL` | only if you want signed-in users to chat without their own key |
   | `TINYFISH_API_KEY` (secret) | optional, web search and link reading for those users |
   | `REQUIRE_AUTH` | `1` when you host your own Gemini key, so only signed-in users can spend it |
6. In `www/index.html` set `const NOVA_API='https://nova-backend.YOURNAME.workers.dev';` (near the top of the script), then rebuild.
   Users can then sign in from Settings with no extra setup. (Anyone can still use their own Gemini key instead.)
   Shortcut: skip this edit and tap **Sign in or create account** in Settings; the sign-in screen asks once for the server address and remembers it on that phone.
7. Google Play needs a web link for account deletion: use `https://nova-backend.YOURNAME.workers.dev/account-deletion`.

## How it works
- Passwords are hashed with PBKDF2-SHA-256 (100,000 rounds, the most Workers allow) and a unique salt. Plain passwords are never stored.
- Session tokens are random, stored only as hashes, last 30 days, and are ended on sign-out, password reset and account deletion.
- 5 wrong passwords lock that email (and that IP) for 15 minutes. Sign-ups are limited to 5 per hour per IP.
- No email is sent. At sign-up the user gets a one-time **recovery code**; it is the only way to reset a forgotten password.
- Sync: each device pulls when the app opens, and pushes a few seconds after a change. If two devices changed things, they are merged.

## Honest limits
- No email verification and no email-based reset (that needs an email service such as Resend; ask me to add it).
- Synced data is stored readable by you, the server operator. It is not end-to-end encrypted. Say so in your privacy policy (done in `PRIVACY.md`).
- Synced: text chats, projects and their code, memory, preferences. Not synced: photos and generated images, API keys.
- Sync is capped at about 850 KB; the oldest chats are skipped first. Deleting a chat on one device can bring it back if another device still has it during a merge.
- The backend was tested here with a simulated database (register, login, lockout, reset, sync conflicts, delete). It was not run on real Cloudflare, and the in-app screens were not run on a device.
- New text in the sign-in screens is English only; the other app languages fall back to English there.
