package com.nova.ai;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.LinearGradient;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.IOException;
import java.io.InputStream;

/** Floating NOVA bubble that stays on top of other apps, with a small quick-chat panel. */
public class OverlayService extends Service {
    public static boolean running = false;
    private static final String CH = "nova_overlay";

    private WindowManager wm;
    private BubbleView bubble;
    private WindowManager.LayoutParams bp;
    private FrameLayout panel;
    private WebView web;
    private boolean open = false;
    private boolean idle = false;
    private int restX;
    private int size, sw, sh;
    private float density;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable idleTask = new Runnable() {
        @Override
        public void run() {
            goIdle();
        }
    };

    private int dp(float v) {
        return (int) (v * density + 0.5f);
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // Android requires startForeground() right after startForegroundService(), even if we stop again.
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        density = dm.density;
        sw = dm.widthPixels;
        sh = dm.heightPixels;
        size = dp(54);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        try {
            buildBubble();
            running = true;
        } catch (Exception e) {
            running = false;
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (bubble == null) { // permission missing or the bubble could not be added: do not restart in a loop
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "NOVA bubble", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, OverlayService.class).setAction("STOP");
        PendingIntent sp = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("NOVA bubble is on")
                .setContentText("Tap Stop to hide it.")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", sp).build());
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- bubble ----------
    private void buildBubble() {
        SharedPreferences sp = getSharedPreferences("nova_overlay", MODE_PRIVATE);
        bubble = new BubbleView(this);
        bp = new WindowManager.LayoutParams(size, size, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.START;
        bp.x = sp.getInt("x", sw - size - dp(6));
        bp.y = sp.getInt("y", sh / 2);
        restX = bp.x;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        wake();
                        startX = bp.x;
                        startY = bp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) + Math.abs(dy) > dp(8)) moved = true;
                        if (moved) {
                            bp.x = (int) (startX + dx);
                            bp.y = (int) (startY + dy);
                            clamp();
                            updateBubble();
                            if (open) closePanel();
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (moved) snap();
                        else toggle();
                        scheduleIdle();
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(bubble, bp);
        scheduleIdle();
    }

    private void clamp() {
        bp.x = Math.max(-dp(24), Math.min(bp.x, sw - size + dp(24)));
        bp.y = Math.max(dp(30), Math.min(bp.y, sh - size - dp(60)));
    }

    private void updateBubble() {
        try {
            wm.updateViewLayout(bubble, bp);
        } catch (Exception ignored) {
        }
    }

    private void animateX(int to) {
        ValueAnimator a = ValueAnimator.ofInt(bp.x, to);
        a.setDuration(220);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                bp.x = (Integer) va.getAnimatedValue();
                updateBubble();
            }
        });
        a.start();
    }

    private void snap() {
        int target = (bp.x + size / 2 < sw / 2) ? dp(6) : sw - size - dp(6);
        restX = target;
        animateX(target);
        getSharedPreferences("nova_overlay", MODE_PRIVATE).edit().putInt("x", target).putInt("y", bp.y).apply();
    }

    private void scheduleIdle() {
        handler.removeCallbacks(idleTask);
        if (!open) handler.postDelayed(idleTask, 3000);
    }

    private void goIdle() {
        if (open || idle || bubble == null) return;
        idle = true;
        bubble.animate().alpha(0.35f).setDuration(500).start();
        animateX(restX < sw / 2 ? -dp(24) : sw - size + dp(24));
    }

    private void wake() {
        handler.removeCallbacks(idleTask);
        if (idle) {
            idle = false;
            bubble.animate().alpha(1f).setDuration(200).start();
            animateX(restX);
        }
    }

    // ---------- quick chat panel (a WebView that loads the same app in ?mini=1 mode) ----------
    private void toggle() {
        if (open) closePanel();
        else openPanel();
    }

    private void openPanel() {
        if (open) return;
        open = true;
        int w = Math.min(dp(340), sw - dp(24));
        int h = Math.min(dp(440), (int) (sh * 0.52f));
        panel = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#0A0A0B"));
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1), Color.parseColor("#558B78FF"));
        panel.setBackground(bg);
        panel.setClipToOutline(true);
        panel.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0A0A0B"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new NovaBridge(), "NovaNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if ("localhost".equals(request.getUrl().getHost())) {
                    String p = request.getUrl().getPath();
                    if (p == null || p.equals("/")) p = "/index.html";
                    try {
                        InputStream in = getAssets().open("public" + p);
                        String mime = p.endsWith(".html") ? "text/html"
                                : p.endsWith(".js") ? "text/javascript"
                                : p.endsWith(".css") ? "text/css"
                                : p.endsWith(".png") ? "image/png"
                                : p.endsWith(".svg") ? "image/svg+xml" : "application/octet-stream";
                        return new WebResourceResponse(mime, "UTF-8", in);
                    } catch (IOException e) {
                        return null;
                    }
                }
                return null;
            }
        });
        panel.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(w, h, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.START;
        pp.x = (restX < sw / 2) ? dp(12) : sw - w - dp(12);
        pp.y = dp(56);
        pp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        wm.addView(panel, pp);
        web.loadUrl("https://localhost/index.html?mini=1");
        handler.removeCallbacks(idleTask);
    }

    private void closePanel() {
        if (!open) return;
        open = false;
        try {
            wm.removeView(panel);
        } catch (Exception ignored) {
        }
        if (web != null) {
            panel.removeAllViews();
            web.destroy();
            web = null;
        }
        panel = null;
        scheduleIdle();
    }

    /** Called from the page: window.NovaNative.close() / openApp() */
    public class NovaBridge {
        @JavascriptInterface
        public void close() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    closePanel();
                }
            });
        }

        @JavascriptInterface
        public void openApp() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    closePanel();
                    Intent i = new Intent(OverlayService.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                }
            });
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        sw = dm.widthPixels;
        sh = dm.heightPixels;
        if (open) closePanel();
        if (bubble != null) {
            clamp();
            snap();
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(idleTask);
        closePanel();
        try {
            if (bubble != null) wm.removeView(bubble);
        } catch (Exception ignored) {
        }
        bubble = null;
        running = false;
        super.onDestroy();
    }

    /** The round glass bubble with the NOVA star. */
    private static class BubbleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path star = new Path();
        private final float d;

        BubbleView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), cx = w / 2f, cy = w / 2f, r = w / 2f - 2 * d;
            // glass body: violet glow at the top-left fading to deep charcoal
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(w * 0.32f, w * 0.25f, w * 0.85f,
                    new int[]{Color.parseColor("#EE9A89FF"), Color.parseColor("#F0241F3D"), Color.parseColor("#F0121216")},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            // soft white rim
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(Color.parseColor("#66FFFFFF"));
            c.drawCircle(cx, cy, r - 0.75f * d, p);
            // specular highlight on top
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, w * 0.08f, 0, w * 0.45f,
                    Color.parseColor("#66FFFFFF"), Color.parseColor("#00FFFFFF"), Shader.TileMode.CLAMP));
            c.drawOval(new RectF(w * 0.2f, w * 0.08f, w * 0.8f, w * 0.46f), p);
            p.setShader(null);
            // NOVA star
            float s = w * 0.26f;
            star.reset();
            star.moveTo(cx, cy - s);
            star.quadTo(cx, cy, cx + s, cy);
            star.quadTo(cx, cy, cx, cy + s);
            star.quadTo(cx, cy, cx - s, cy);
            star.quadTo(cx, cy, cx, cy - s);
            star.close();
            p.setColor(Color.WHITE);
            c.drawPath(star, p);
            // online dot
            p.setColor(Color.parseColor("#FF4ADE80"));
            c.drawCircle(w * 0.80f, w * 0.20f, 4.5f * d, p);
        }
    }
}
