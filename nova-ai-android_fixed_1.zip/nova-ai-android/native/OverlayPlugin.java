package com.nova.ai;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NovaOverlay")
public class OverlayPlugin extends Plugin {

    @PluginMethod
    public void status(PluginCall call) {
        JSObject o = new JSObject();
        o.put("granted", Settings.canDrawOverlays(getContext()));
        o.put("running", OverlayService.running);
        call.resolve(o);
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        Context c = getContext();
        if (!Settings.canDrawOverlays(c)) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (Exception e) {
                // Some phones hide that screen: open the app's own settings page instead
                Intent a = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.getPackageName()));
                a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(a);
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void start(PluginCall call) {
        Context c = getContext();
        if (!Settings.canDrawOverlays(c)) {
            call.reject("permission");
            return;
        }
        // Android 13+: without this the "NOVA bubble is on" notification (and its Stop button) stays hidden
        if (Build.VERSION.SDK_INT >= 33 && getActivity() != null
                && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            getActivity().requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 4711);
        }
        Intent i = new Intent(c, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
        call.resolve();
    }

    @PluginMethod
    public void batterySettings(PluginCall call) {
        Context c = getContext();
        try {
            Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            Intent a = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.getPackageName()));
            a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(a);
        }
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Context c = getContext();
        c.stopService(new Intent(c, OverlayService.class));
        call.resolve();
    }
}
