// One-step setup: node setup.js   (run `npm install` first)
// Adds the Android project, native floating-bubble code, permissions and icon, then syncs.
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const run = c => { console.log('> ' + c); execSync(c, { stdio: 'inherit' }); };

if (!fs.existsSync('android')) run('npx cap add android');

// 1) Native overlay code (bubble that floats over other apps)
const pkgDir = 'android/app/src/main/java/com/nova/ai';
fs.mkdirSync(pkgDir, { recursive: true });
for (const f of ['MainActivity.java', 'OverlayPlugin.java', 'OverlayService.java'])
  fs.copyFileSync(path.join('native', f), path.join(pkgDir, f));
console.log('Native overlay files installed.');

// 2) Manifest: permissions + overlay service
const mf = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(mf, 'utf8');
const perms = ['RECORD_AUDIO', 'CAMERA', 'MODIFY_AUDIO_SETTINGS', 'SYSTEM_ALERT_WINDOW',
  'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_SPECIAL_USE', 'POST_NOTIFICATIONS'];
let add = '';
for (const p of perms)
  if (!m.includes('android.permission.' + p)) add += `    <uses-permission android:name="android.permission.${p}" />\n`;
if (!m.includes('android.speech.RecognitionService'))
  add += '    <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n';
if (add) m = m.replace('</manifest>', add + '</manifest>');
// Keys live on the phone: keep them out of Android cloud backups
m = m.replace('android:allowBackup="true"', 'android:allowBackup="false"');
if (!m.includes('com.nova.ai.OverlayService'))
  m = m.replace('</application>',
    '        <service android:name="com.nova.ai.OverlayService" android:exported="false" android:foregroundServiceType="specialUse">\n' +
    '            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="floating_assistant_bubble" />\n' +
    '        </service>\n    </application>');
fs.writeFileSync(mf, m);
console.log('Manifest patched.');

// 2b) Official release setup: signing + version (see RELEASE.md)
const patchGradle = require('./scripts/patch-gradle.js');
const gp = 'android/app/build.gradle';
const res = patchGradle(fs.readFileSync(gp, 'utf8'), require('./package.json').version);
if (res.changed) fs.writeFileSync(gp, res.text);
console.log(res.ok ? 'Release signing configured.' : 'WARNING: could not patch build.gradle for signing. Open android/app/build.gradle and follow RELEASE.md, Manual signing.');

// 3) Icon + splash, then sync web files
try { run('npx capacitor-assets generate --android'); } catch (e) { console.log('Icon generation skipped.'); }
run('npx cap sync android');
console.log('\nDone. Next: npm run open  (Android Studio) then Build > Build APK(s),\nor push to GitHub and run the "Build NOVA APK" workflow.');
