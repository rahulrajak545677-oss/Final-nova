# Releasing NOVA AI as an official app

Debug builds (the old workflow) are for testing only. A release build is signed with **your own permanent key**,
which is what makes Android treat it as the same app on every update and lets you publish it.

## 1. Before you start
- Set the real app id in `capacitor.config.json` (`appId`, default `com.nova.ai`). **Change it before your first release if you want a different one: it can never change later.**
- Bump `version` in `package.json` for each update. The version code goes up automatically with every cloud build.

## 2. Create your signing key (once)
```
npm install
npm run keystore
```
This makes `nova-release.keystore` and `nova-release.keystore.b64.txt`. Use one strong password for both questions.
**Back up the keystore and the password in two safe places. Never upload them to GitHub.**
If you lose them you cannot update the app under the same signature (publishing through Google Play App Signing, step 6, protects you from this).

## 3. Add four secrets to GitHub
Repo > Settings > Secrets and variables > Actions > New repository secret:
| Secret | Value |
|---|---|
| `NOVA_KEYSTORE_B64` | the whole text inside `nova-release.keystore.b64.txt` |
| `NOVA_KEYSTORE_PASSWORD` | your keystore password |
| `NOVA_KEY_ALIAS` | `nova` |
| `NOVA_KEY_PASSWORD` | the same password |

## 4. Build
Actions > **Build NOVA release (signed)** > Run workflow (or push a tag such as `v2.0.0`).
Download **nova-ai-release**: `app-release.apk` (install and share directly) and `app-release.aab` (Google Play).
The workflow checks the APK signature and fails if anything is missing.

## 5. Build on your own computer instead
Create `android/keystore.properties`:
```
storeFile=release.keystore
storePassword=YOUR_PASSWORD
keyAlias=nova
keyPassword=YOUR_PASSWORD
```
Copy `nova-release.keystore` to `android/app/release.keystore`, then run `node setup.js` and `npm run release`.
Outputs: `android/app/build/outputs/apk/release/` and `.../bundle/release/`.
Manual signing (if setup says it could not patch `build.gradle`): add a `signingConfigs.release` block and
`signingConfig signingConfigs.release` inside `buildTypes.release` in `android/app/build.gradle`.

## 6. Publishing on Google Play (checklist)
- Create a Play Console developer account, a new app, and upload the **.aab**. Enrol in **Play App Signing** (default).
- **Accounts (if you set up the backend, ACCOUNTS.md):** enter the `/account-deletion` page as the account deletion URL, and in the Data safety form declare email address and user content as collected for app functionality, with deletion available.
- **Privacy policy:** publish a web page from `PRIVACY.md` (edit the contact line) and enter its URL.
- **Data safety form:** declare what is in `PRIVACY.md` (chats and images sent to Google Gemini / TinyFish / Pollinations at the user's request, on-device storage, microphone and camera use).
- **Foreground service declaration** (the bubble uses the special-use type) and a clear reason for **"Display over other apps"**. Google reviews both closely; if the bubble causes a rejection, ship without it first.
- Content rating questionnaire, store listing (icon, screenshots, description), target audience, and the AI-generated content declaration if asked.
- New personal developer accounts may have to run a closed test before production. Check the current rules in Play Console.
- Test the **release** APK on a real phone first: chat, image, voice, bubble, rotate, offline.

## Things this does not do
- Accounts and sync are optional and need the Cloudflare backend (ACCOUNTS.md). Without it, chats and keys stay on the phone.
- Code shrinking (R8) is off on purpose: it can break the native bubble plugin and is untested. Turn it on later if you want a smaller APK.
- Nothing here has been built or run on a device by me. Expect to fix small build errors on the first run.
