package com.nova.ai;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Native read-aloud: uses the phone's own text-to-speech engine (the WebView one is unreliable). */
@CapacitorPlugin(name = "NovaTts")
public class TtsPlugin extends Plugin {
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ready = false, failed = false;
    private final List<Runnable> waiting = new ArrayList<>();
    private PluginCall current;
    private volatile String lastId = "";
    private int seq = 0;

    private void init(final Runnable then) {
        if (ready || failed) {
            then.run();
            return;
        }
        waiting.add(then);
        if (tts != null) return;
        tts = new TextToSpeech(getContext().getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(final int status) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        ready = status == TextToSpeech.SUCCESS;
                        failed = !ready;
                        if (ready) {
                            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                                @Override
                                public void onStart(String id) {
                                }

                                @Override
                                public void onDone(String id) {
                                    finish(id);
                                }

                                @Override
                                public void onError(String id) {
                                    finish(id);
                                }

                                @Override
                                public void onStop(String id, boolean interrupted) {
                                    finish(id);
                                }
                            });
                        }
                        List<Runnable> w = new ArrayList<>(waiting);
                        waiting.clear();
                        for (Runnable r : w) r.run();
                    }
                });
            }
        });
    }

    private void finish(final String id) {
        if (id == null || !id.equals(lastId)) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                if (current != null) {
                    PluginCall c = current;
                    current = null;
                    c.resolve();
                }
            }
        });
    }

    private static List<String> chunk(String text) {
        List<String> out = new ArrayList<>();
        int max = 3000;
        String t = text.trim();
        while (t.length() > max) {
            int cut = Math.max(t.lastIndexOf(". ", max), Math.max(t.lastIndexOf("\n", max), t.lastIndexOf(" ", max)));
            if (cut < max / 2) cut = max;
            out.add(t.substring(0, cut + 1).trim());
            t = t.substring(cut + 1).trim();
        }
        if (!t.isEmpty()) out.add(t);
        return out;
    }

    @PluginMethod
    public void speak(final PluginCall call) {
        final String text = call.getString("text", "");
        final String lang = call.getString("lang", "");
        if (text == null || text.trim().isEmpty()) {
            call.resolve();
            return;
        }
        main.post(new Runnable() {
            @Override
            public void run() {
                init(new Runnable() {
                    @Override
                    public void run() {
                        if (!ready) {
                            call.reject("unavailable");
                            return;
                        }
                        lastId = "";
                        tts.stop();
                        if (current != null) {
                            PluginCall old = current;
                            current = null;
                            old.resolve();
                        }
                        current = call;
                        if (lang != null && !lang.isEmpty()) {
                            int r = tts.setLanguage(Locale.forLanguageTag(lang));
                            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                                tts.setLanguage(Locale.getDefault());
                            }
                        }
                        List<String> parts = chunk(text);
                        for (int i = 0; i < parts.size(); i++) {
                            String id = "nova" + (++seq);
                            lastId = id;
                            int rc = tts.speak(parts.get(i), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, new Bundle(), id);
                            if (rc != TextToSpeech.SUCCESS) {
                                current = null;
                                call.reject("unavailable");
                                return;
                            }
                        }
                    }
                });
            }
        });
    }

    @PluginMethod
    public void stop(final PluginCall call) {
        main.post(new Runnable() {
            @Override
            public void run() {
                lastId = "";
                if (tts != null && ready) tts.stop();
                if (current != null) {
                    PluginCall c = current;
                    current = null;
                    c.resolve();
                }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void isSpeaking(PluginCall call) {
        JSObject o = new JSObject();
        o.put("speaking", tts != null && ready && tts.isSpeaking());
        call.resolve(o);
    }

    @Override
    protected void handleOnDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.handleOnDestroy();
    }
}
